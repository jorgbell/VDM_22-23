package com.nonogram.engine;

public interface Font {
    int getSize();
    void setSize(int size);
    void setBold(boolean bold);
    boolean isBold();
}
