package com.nonogram.engine;

public interface Image {
    int getWidth();
    int getHeight();
}
