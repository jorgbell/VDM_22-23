package com.nonogram.engine;

public interface IntentManager {

    public void shareImage(String imagePath);
}
