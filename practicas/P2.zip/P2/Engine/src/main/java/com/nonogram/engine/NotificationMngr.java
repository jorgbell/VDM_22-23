package com.nonogram.engine;

public interface NotificationMngr {
    void setEngine(Engine e);
}
