package com.example.modpc;

public class HelloWorld {

    public static void main(String args[]) {

        GUI gui = new GUI("finestra",300,300);

    }


}